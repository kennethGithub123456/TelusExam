
//Cypress - Spec


describe('first test api post', function(){

    

    
    it('Test POST Request', () => {
        cy.request({
             method: "POST",
             url: "https://reqres.in/api/users",
             body: {
                name: "paul rudds",
                movies: ["I Love You Man", "Role Models"]
             }
        }).then((response) => { 
                expect(response.body).to.have.property('code', 201);
                expect(response.body).has.property('id');
                expect(response.body).has.property('createdAt');

        })
  })






})