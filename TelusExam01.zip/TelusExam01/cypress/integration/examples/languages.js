


 it('languages', function()
 {
    ///////////////Access lanugage page/////////////////////////
cy.get('.sui-flex.sui-flex-col.sui-gap-4 > a:nth-of-type(2)').click()
cy.url().should('eq', 'https://www.telusinternational.ai/cmp/contributor/userprofile/languages')

 ///////////////add primary lanugage /////////////////////////
cy.get('.css-1uccc91-singleValue.sui-c-floating-label-dropdown.sui-c-input-dropdown__single-value').select('French (Niger)')
cy.get('button[type=submit]').click()

 ///////////////add other lanugage /////////////////////////
 
 cy.get ('[class=col-lg-2 col-md-2] button').click()
 cy.get('#new-language-form .figma-input-field-length:nth-of-type(1) .sui-c-input-dropdown__value-container').select('Akan (Ghna)')
 cy.get('.figma-input-field-margin .sui-c-input-dropdown__value-container').select('Full working proficiency')
 cy.get('button[type=submit]').click()

 })