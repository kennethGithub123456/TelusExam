//Cypress - Spec

describe('Telus Exam', function()
{
    it('Log in', function()
    {
   cy.visit("https://www.telusinternational.ai/cmp")
   cy.get('input[name=email]').type('pea_kenneth@yahoo.com')
 
   cy.get('button[type=submit]').click()
  
   cy.get('input[name=password]').type('Telus_123456')

   cy.get('button[type=submit]').click()

   cy.get('.sui-text-b4.sui-text-darkGray-darker.sui-text-lightGray-darkest.tw-mt-1').should('have.text','631ef26847a1572b39244ee2' )


  

    })

   
})